# PynamiX

[Documentation here](https://pages.github.sydney.edu.au/scigem/pynamix/build/html/index.html)

## Installation
Work in progress. Hopefully via `pip install pynamix` but YMMV.

## Dependencies
Work in progress - should be handled in pip install. Currently requires `python3`.

## Documentation

We use `sphinx` to manage the docs. Update documentation with:
```
cd docs
make html
```
Once these are built, you can commit and push the changes to github to have them refreshed on github pages.
